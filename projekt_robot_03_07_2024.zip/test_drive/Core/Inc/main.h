/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define NOT_USED_BUTTON_Pin GPIO_PIN_13
#define NOT_USED_BUTTON_GPIO_Port GPIOC
#define TYLNI_ODBICIA_Pin GPIO_PIN_15
#define TYLNI_ODBICIA_GPIO_Port GPIOC
#define ANALOGOWY_LEWY_Pin GPIO_PIN_0
#define ANALOGOWY_LEWY_GPIO_Port GPIOA
#define ANALOGOWY_PRAWY_Pin GPIO_PIN_1
#define ANALOGOWY_PRAWY_GPIO_Port GPIOA
#define SILNIK_PRAWY_TYL_Pin GPIO_PIN_6
#define SILNIK_PRAWY_TYL_GPIO_Port GPIOA
#define PRZEDNI_LEWY_ODBICIA_Pin GPIO_PIN_4
#define PRZEDNI_LEWY_ODBICIA_GPIO_Port GPIOC
#define PRZEDNI_PRAWY_ODBICIA_Pin GPIO_PIN_2
#define PRZEDNI_PRAWY_ODBICIA_GPIO_Port GPIOB
#define SILNIK_PRAWY_PRZOD_Pin GPIO_PIN_10
#define SILNIK_PRAWY_PRZOD_GPIO_Port GPIOB
#define PRAWY_ODBICIA_Pin GPIO_PIN_9
#define PRAWY_ODBICIA_GPIO_Port GPIOC
#define ECHO_ULTRA_Pin GPIO_PIN_8
#define ECHO_ULTRA_GPIO_Port GPIOA
#define TRIG_ULTRA_Pin GPIO_PIN_9
#define TRIG_ULTRA_GPIO_Port GPIOA
#define LEWY_ODBICIA_Pin GPIO_PIN_2
#define LEWY_ODBICIA_GPIO_Port GPIOD
#define SILNIK_LEWY_PRZOD_Pin GPIO_PIN_3
#define SILNIK_LEWY_PRZOD_GPIO_Port GPIOB
#define SILNIK_LEWY_TYL_Pin GPIO_PIN_5
#define SILNIK_LEWY_TYL_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
